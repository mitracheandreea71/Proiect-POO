#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"conexiuneserver.h"
#include"login.h"
#include"sign.h"
#include<QPainter>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QPixmap atm("C:/Users/mitra/Desktop/client/atm.png");
    QPixmap slt("C:/Users/mitra/Desktop/client/slt.png");
    QBitmap mask(atm.size());
    mask.fill(Qt::color0);
    QPainter painter(&mask);
    painter.setBrush(Qt::color1);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.drawEllipse(mask.rect());
    atm.setMask(mask);

    QBitmap mask2(slt.size());
    mask2.fill(Qt::color0);
    QPainter painter2(&mask2);
    painter2.setBrush(Qt::color1);
    painter2.setRenderHint(QPainter::Antialiasing);
    painter2.drawEllipse(mask2.rect());
    slt.setMask(mask2);
    ui->label_5->setPixmap(atm);
    ui->label_5->setScaledContents(true);

    ui->label_4->setPixmap(slt);
    ui->label_4->setScaledContents(true);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_Login_clicked() {
    static  Login l;
    hide();
    l.show();
  }

void MainWindow::on_pushButton_Sign_clicked()
{
    static Sign s;
    hide();
    s.show();
}

