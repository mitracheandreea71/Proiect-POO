#include "admin.h"
#include "ui_admin.h"
#include"conexiuneserver.h"
#include<QPainter>
#include <QDialog>
#include <QPushButton>
#include <QVBoxLayout>
#include<QMessageBox>
#include<QSpinBox>
#include<QScrollArea>
#include<QComboBox>
#include"mainwindow.h"

Admin::Admin(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Admin)
{
    ui->setupUi(this);
    QPixmap img("C:/Users/mitra/Desktop/client/slt.png");
    QBitmap mask(img.size());
    mask.fill(Qt::color0);
    QPainter painter(&mask);
    painter.setBrush(Qt::color1);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.drawEllipse(mask.rect());
    img.setMask(mask);

    ui->label_imgUser->setPixmap(img);
    ui->label_imgUser->setScaledContents(true);
    client& Client=client::getInstance();

    ui->pushButton_cont->setText(Client.getNume());

    connect(ui->pushButton_VizSC, &QPushButton::clicked, this, &Admin::on_pushButton_VizSC_clicked);
    connect(ui->pushButton_VizSN, &QPushButton::clicked, this, &Admin::on_pushButton_VizSN_clicked);
    connect(ui->pushButton_VizFCreate, &QPushButton::clicked, this, &Admin::on_pushButton_VizFCreate_clicked);
    connect(ui->pushButton_VizStatistica, &QPushButton::clicked, this, &Admin::on_pushButton_VizStatistica_clicked);
    connect(ui->pushButton_VizFormular, &QPushButton::clicked, this, &Admin::on_pushButton_VizFormular_clicked);
    connect(ui->pushButton_CompletareS, &QPushButton::clicked, this, &Admin::on_pushButton_CompletareS_clicked);
    connect(ui->pushButton_CreareF, &QPushButton::clicked, this, &Admin::on_pushButton_CreareF_clicked);
    connect(ui->pushButton_CerereArhivare, &QPushButton::clicked, this, &Admin::on_pushButton_CerereArhivare_clicked);
    connect(ui->pushButton_StergereF, &QPushButton::clicked, this, &Admin::on_pushButton_StergereF_clicked);
    connect(ui->pushButton_ArhivareF, &QPushButton::clicked, this, &Admin::on_pushButton_ArhivareF_clicked);
    connect(ui->pushButton_Clear, &QPushButton::clicked, this, &Admin::on_pushButton_Clear_clicked);
   // connect(ui->pushButton_View, &QPushButton::clicked, this, &Admin::on_pushButton_View_clicked);
    connect(ui->pushButton_Cancel, &QPushButton::clicked, this, &Admin::on_pushButton_Cancel_clicked);

    ui->label_AlegereSondaj->setVisible(false);
    ui->label_vizualizare->setVisible(false);
    ui->listWidget->setVisible(false);
    ui->pushButton_Clear->setVisible(false);
    ui->lineEdit_Sondaj->setVisible(false);
    ui->pushButton_Cancel->setVisible(false);
    ui->pushButton_View->setVisible(false);
}

Admin::~Admin()
{
    delete ui;
}

void Admin::on_pushButton_VizSC_clicked()
{
    ui->listWidget->clear();
    ui->label_vizualizare->setVisible(true);
    ui->listWidget->setVisible(true);
    ui->pushButton_Clear->setVisible(true);
    ui->label_vizualizare->setText("Formulare completate");
    client& Client=client::getInstance();
    QByteArray authMessage;
    authMessage.append("FormulareCompletate|");
    QByteArray usernameBytes = Client.getNume().toUtf8();
    authMessage.append(usernameBytes);
    const char* charArray = authMessage.constData();
    Client.send_message(charArray);
    const char*response=Client.response();
    QString responseStr(response);
    QStringList namesList = responseStr.split('|');
    foreach (const QString &name, namesList) {
        ui->listWidget->addItem(name);
    }
}


void Admin::on_pushButton_VizSN_clicked()
{
    ui->listWidget->clear();
    ui->label_vizualizare->setVisible(true);
    ui->listWidget->setVisible(true);
    ui->pushButton_Clear->setVisible(true);
    ui->label_vizualizare->setText("Formulare necompletate");
    client& Client=client::getInstance();
    QByteArray authMessage;
    authMessage.append("FormulareNecompletate|");
    QByteArray usernameBytes = Client.getNume().toUtf8();
    authMessage.append(usernameBytes);
    const char* charArray = authMessage.constData();
    Client.send_message(charArray);
    const char*response=Client.response();
    QString responseStr(response);
    QStringList namesList = responseStr.split('|');
    foreach (const QString &name, namesList) {
        ui->listWidget->addItem(name);
    }
}


void Admin::on_pushButton_VizFCreate_clicked()
{
    ui->listWidget->clear();
    ui->label_vizualizare->setVisible(true);
    ui->listWidget->setVisible(true);
    ui->pushButton_Clear->setVisible(true);
    ui->label_vizualizare->setText("Formulare create");
    client& Client=client::getInstance();
    QByteArray authMessage;
    authMessage.append("FormulareCreate|");
    QByteArray usernameBytes = Client.getNume().toUtf8();
    authMessage.append(usernameBytes);
    const char* charArray = authMessage.constData();
    Client.send_message(charArray);
    const char*response=Client.response();
    QString responseStr(response);
    QStringList namesList = responseStr.split('|');
    foreach (const QString &name, namesList) {
        ui->listWidget->addItem(name);
    }
}


void Admin::on_pushButton_VizStatistica_clicked()
{
    ui->lineEdit_Sondaj->clear();
    ui->label_AlegereSondaj->setVisible(true);
    ui->lineEdit_Sondaj->setVisible(true);
    ui->pushButton_Cancel->setVisible(true);
    ui->pushButton_View->setVisible(true);
    ui->pushButton_View->setText("Statistica");
    ui->label_AlegereSondaj->setText("Completeaza numele formularului pentru care doresti sa vezi statistica:");

}


void Admin::on_pushButton_VizFormular_clicked()
{
    ui->lineEdit_Sondaj->clear();
    ui->label_AlegereSondaj->setVisible(true);
    ui->lineEdit_Sondaj->setVisible(true);
    ui->pushButton_Cancel->setVisible(true);
    ui->pushButton_View->setVisible(true);
    ui->pushButton_View->setText("View");
    ui->label_AlegereSondaj->setText("Completeaza numele formularului pe care doresti sa-l vizualizezi:");

}

void Admin::on_pushButton_CompletareS_clicked()
{
    ui->lineEdit_Sondaj->clear();
    ui->label_AlegereSondaj->setVisible(true);
    ui->lineEdit_Sondaj->setVisible(true);
    ui->pushButton_Cancel->setVisible(true);
    ui->pushButton_View->setVisible(true);
    ui->pushButton_View->setText("Fill");
    ui->label_AlegereSondaj->setText("Completeaza numele formularului pe care doresti sa-l completezi:");

}

void Admin::showQuestionsDialogS(const QString &surveyName, int questionCount)
{
    QDialog dialog(this);
    dialog.setWindowTitle("Introdu întrebările");
    dialog.resize(400, 300);
    dialog.setStyleSheet("background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(74, 144, 226, 255), stop:1 rgba(74, 144, 226, 0));");
    QVBoxLayout *layout = new QVBoxLayout(&dialog);
    client& Client=client::getInstance();
    QByteArray authMessage;
    authMessage.append("C|");
    QByteArray utilizator=Client.getNume().toUtf8();
    authMessage.append(utilizator);
    authMessage.append("|sondaj|");
    QByteArray nume=surveyName.toUtf8();
    authMessage.append(nume);
    authMessage.append("|");
    QVector<QLineEdit*> lineEdits;
    for (int i = 0; i < questionCount; ++i) {
        QLabel *labelQuestion = new QLabel(QString("Întrebarea %1:").arg(i + 1), &dialog);
        QLineEdit *lineEditQuestion = new QLineEdit(&dialog);
        lineEditQuestion->setStyleSheet("QLineEdit{background-color:white}");
        lineEdits.push_back(lineEditQuestion);
        layout->addWidget(labelQuestion);
        layout->addWidget(lineEditQuestion);

    }

    QPushButton *finishButton = new QPushButton("Finish", &dialog);
    finishButton->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:5px; border: 1px solid #000000; }");

    layout->addWidget(finishButton);

    connect(finishButton, &QPushButton::clicked, [&]() {
        for(QLineEdit* lineEdit : lineEdits){
            QString intrebare = lineEdit->text();
            QByteArray intrebareData = intrebare.toUtf8();
            authMessage.append(intrebareData);
            authMessage.append("|");}
        // Aici puteți trimite mesajul la server utilizând `authMessage`
        Client.send_message(authMessage);
        dialog.accept();
    });

    dialog.exec();
     const char*response3=Client.response();
    QMessageBox::information(this,"Creare",response3);
}

void Admin::showQuestionsDialogC(const QString &surveyName, int questionCount)
{
    QDialog dialog(this);
    dialog.setWindowTitle("Introdu întrebările și răspunsurile");
    dialog.resize(600, 400);
    dialog.setStyleSheet("background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(74, 144, 226, 255), stop:1 rgba(74, 144, 226, 0));");

    QVBoxLayout *mainLayout = new QVBoxLayout(&dialog);

    QScrollArea *scrollArea = new QScrollArea(&dialog);
    QWidget *scrollWidget = new QWidget();
    QVBoxLayout *scrollLayout = new QVBoxLayout(scrollWidget);

    client& Client = client::getInstance();
    QByteArray authMessage;
    authMessage.append("C|");
    QByteArray utilizator=Client.getNume().toUtf8();
    authMessage.append(utilizator);
    authMessage.append("|chestionar|");
    QByteArray nume = surveyName.toUtf8();
    authMessage.append(nume);
    authMessage.append("|");

    QVector<QLineEdit*> questionLineEdits;
    QVector<QVector<QLineEdit*>> answerLineEdits(questionCount);

    for (int i = 0; i < questionCount; ++i) {
        QLabel *labelQuestion = new QLabel(QString("Întrebarea %1:").arg(i + 1), scrollWidget);
        QLineEdit *lineEditQuestion = new QLineEdit(scrollWidget);
        lineEditQuestion->setStyleSheet("QLineEdit{background-color:white}");
        questionLineEdits.push_back(lineEditQuestion);
        scrollLayout->addWidget(labelQuestion);
        scrollLayout->addWidget(lineEditQuestion);

        for (int j = 0; j < 3; ++j) {
            QLabel *labelAnswer = new QLabel(QString("---Răspunsul %1:").arg(j + 1), scrollWidget);
            QLineEdit *lineEditAnswer = new QLineEdit(scrollWidget);
            lineEditAnswer->setStyleSheet("QLineEdit{background-color:white}");
            answerLineEdits[i].push_back(lineEditAnswer);
            scrollLayout->addWidget(labelAnswer);
            scrollLayout->addWidget(lineEditAnswer);
        }
    }

    scrollWidget->setLayout(scrollLayout);
    scrollArea->setWidget(scrollWidget);
    scrollArea->setWidgetResizable(true);
    mainLayout->addWidget(scrollArea);

    QPushButton *finishButton = new QPushButton("Finish", &dialog);
    finishButton->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:5px; border: 1px solid #000000; }");
    mainLayout->addWidget(finishButton);

    connect(finishButton, &QPushButton::clicked, [&]() {
        for (int i = 0; i < questionCount; ++i) {
            QString question = questionLineEdits[i]->text();
            authMessage.append(question.toUtf8());
            authMessage.append("*");
            for (int j = 0; j < answerLineEdits[i].size(); ++j) {
                QString answer = answerLineEdits[i][j]->text();
                authMessage.append(answer.toUtf8());
                if (j < answerLineEdits[i].size() - 1) {
                    authMessage.append("*");
                }
            }
            authMessage.append("|");
        }

        Client.send_message(authMessage);
        dialog.accept();
    });

    dialog.exec();
     const char*response3=Client.response();
     QMessageBox::information(this,"Creare",response3);
}

void Admin::showNameAndQuestionCountDialogS(const QString &windowTitle)
{
    QDialog dialog(this);
    dialog.setWindowTitle("Introdu numărul de întrebări");
    dialog.resize(300, 200);
    dialog.setStyleSheet("background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(74, 144, 226, 255), stop:1 rgba(74, 144, 226, 0));");
    QVBoxLayout *layout = new QVBoxLayout(&dialog);

    QLabel *labelName = new QLabel("Numele:", &dialog);
    QLineEdit *lineEditName = new QLineEdit(&dialog);
    lineEditName->setStyleSheet("QLineEdit{background-color:white}");
    QLabel *labelQuestionCount = new QLabel("Numărul de întrebări:", &dialog);
    QSpinBox *spinBoxQuestionCount = new QSpinBox(&dialog);
    spinBoxQuestionCount->setStyleSheet("background-color:white");
    spinBoxQuestionCount->setRange(1, 100); // Setăm o limită pentru numărul de întrebări

    QPushButton *nextButton = new QPushButton("Next", &dialog);

    nextButton->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:5px; border: 1px solid #000000; }");

    layout->addWidget(labelName);
    layout->addWidget(lineEditName);
    layout->addWidget(labelQuestionCount);
    layout->addWidget(spinBoxQuestionCount);
    layout->addWidget(nextButton);

    connect(nextButton, &QPushButton::clicked, [this, &dialog, lineEditName, spinBoxQuestionCount]() {
        QString name = lineEditName->text();
        int questionCount = spinBoxQuestionCount->value();
        dialog.accept();
        showQuestionsDialogS(name, questionCount);

    });

    dialog.exec();
}

void Admin::showNameAndQuestionCountDialogC(const QString &windowTitle)
{
    QDialog dialog(this);
    dialog.setWindowTitle("Introdu numărul de întrebări");
    dialog.resize(300, 200);
    dialog.setStyleSheet("background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(74, 144, 226, 255), stop:1 rgba(74, 144, 226, 0));");
    QVBoxLayout *layout = new QVBoxLayout(&dialog);

    QLabel *labelName = new QLabel("Numele:", &dialog);
    QLineEdit *lineEditName = new QLineEdit(&dialog);
    lineEditName->setStyleSheet("QLineEdit{background-color:white}");
    QLabel *labelQuestionCount = new QLabel("Numărul de întrebări:", &dialog);
    QSpinBox *spinBoxQuestionCount = new QSpinBox(&dialog);
    spinBoxQuestionCount->setStyleSheet("background-color:white");
    spinBoxQuestionCount->setRange(1, 100); // Setăm o limită pentru numărul de întrebări

    QPushButton *nextButton = new QPushButton("Next", &dialog);

    nextButton->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:5px; border: 1px solid #000000; }");

    layout->addWidget(labelName);
    layout->addWidget(lineEditName);
    layout->addWidget(labelQuestionCount);
    layout->addWidget(spinBoxQuestionCount);
    layout->addWidget(nextButton);

    connect(nextButton, &QPushButton::clicked, [this, &dialog, lineEditName, spinBoxQuestionCount]() {
        QString name = lineEditName->text();
        int questionCount = spinBoxQuestionCount->value();
        dialog.accept();
        showQuestionsDialogC(name, questionCount);
    });

    dialog.exec();
}

void Admin::on_pushButton_CreareF_clicked()
{

    QDialog dialog(this);
    dialog.setWindowTitle("Alege tipul de formular");
    dialog.resize(200, 150);
    dialog.setStyleSheet("background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(74, 144, 226, 255), stop:1 rgba(74, 144, 226, 0));");

    QVBoxLayout *layout = new QVBoxLayout(&dialog);

    QPushButton *buttonSondaj = new QPushButton("Sondaj", &dialog);
    QPushButton *buttonChestionar = new QPushButton("Chestionar", &dialog);

    buttonSondaj->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:10px; border: 1px solid #000000; }");
    buttonSondaj->setFixedSize(100, 50);

    buttonChestionar->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:10px; border: 1px solid #000000; }");
    buttonChestionar->setFixedSize(100, 50);

    layout->addWidget(buttonSondaj);
    layout->addWidget(buttonChestionar);

    connect(buttonSondaj, &QPushButton::clicked, [this, &dialog]() {
        dialog.accept();
        showNameAndQuestionCountDialogS("Fereastra Sondaj");
    });

    connect(buttonChestionar, &QPushButton::clicked, [this, &dialog]() {
        dialog.accept();
        showNameAndQuestionCountDialogC("Fereastra Chestionar");
    });

    dialog.exec();

}


void Admin::on_pushButton_CerereArhivare_clicked()
{
    ui->listWidget->clear();
    ui->label_vizualizare->setVisible(true);
    ui->listWidget->setVisible(true);
    ui->pushButton_Clear->setVisible(true);
    ui->label_vizualizare->setText("Cereri arhivare formulare");
    client& Client=client::getInstance();
    QByteArray authMessage;
    authMessage.append("VizualizareCereriArhivare|");
    QByteArray usernameBytes = Client.getNume().toUtf8();
    authMessage.append(usernameBytes);
    const char* charArray = authMessage.constData();
    Client.send_message(charArray);
    const char*response=Client.response();
    QString responseStr(response);
    QStringList namesList = responseStr.split('|');
    foreach (const QString &name, namesList) {
        ui->listWidget->addItem(name);
    }
}


void Admin::on_pushButton_StergereF_clicked()
{
    ui->lineEdit_Sondaj->clear();
    ui->label_AlegereSondaj->setVisible(true);
    ui->lineEdit_Sondaj->setVisible(true);
    ui->pushButton_Cancel->setVisible(true);
    ui->pushButton_View->setVisible(true);
    ui->pushButton_View->setText("Sterge");
    ui->label_AlegereSondaj->setText("Completeaza numele formularului pe care doresti sa-l stergi:");

}


void Admin::on_pushButton_ArhivareF_clicked()
{
    ui->lineEdit_Sondaj->clear();
    ui->label_AlegereSondaj->setVisible(true);
    ui->lineEdit_Sondaj->setVisible(true);
    ui->pushButton_Cancel->setVisible(true);
    ui->pushButton_View->setVisible(true);
    ui->pushButton_View->setText("Arhiveaza");
    ui->label_AlegereSondaj->setText("Completeaza numele formularului pe care doresti sa-l arhivezi:");

}


void Admin::on_pushButton_Clear_clicked()
{
    ui->label_vizualizare->setVisible(false);
    ui->listWidget->setVisible(false);
    ui->pushButton_Clear->setVisible(false);
    ui->listWidget->clear();
}


void Admin::on_pushButton_View_clicked()
{
    if(ui->pushButton_View->text()=="View"){

        QString nume=ui->lineEdit_Sondaj->text();

        client& Client = client::getInstance();
        QByteArray requestMessage;
        requestMessage.append("FormularCompletatDeMine|");
        requestMessage.append(Client.getNume().toUtf8());
        requestMessage.append("|");
        requestMessage.append(nume.toUtf8());
        const char* charArray = requestMessage.constData();
        Client.send_message(charArray);


        const char* response = Client.response();

        if(strcmp(response,"Formular gresit")==0){
            QMessageBox::warning(this, "Warning", "Formularul nu e completat");
        }
        else{
        QDialog dialog(this);
        dialog.setWindowTitle("Vizualizare Formular");
        dialog.resize(600, 400);
        dialog.setStyleSheet("background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(74, 144, 226, 255), stop:1 rgba(74, 144, 226, 0));");
        QVBoxLayout *mainLayout = new QVBoxLayout(&dialog);

        QScrollArea *scrollArea = new QScrollArea(&dialog);
        scrollArea->setWidgetResizable(true);

        QWidget *scrollWidget = new QWidget();
        QVBoxLayout *scrollLayout = new QVBoxLayout(scrollWidget);

        QString responseString(response);
        QStringList questionAnswerPairs = responseString.split("|");

        for (const QString& pair : questionAnswerPairs) {
            QStringList questionAnswer = pair.split("*");

            if (questionAnswer.size() == 2) {
                QString question = questionAnswer[0];
                QString answer = questionAnswer[1];

                QLabel *questionLabel = new QLabel(question, &dialog);
                QLabel *answerLabel = new QLabel(answer, &dialog);

                scrollLayout->addWidget(questionLabel);
                scrollLayout->addWidget(answerLabel);
            }
        }

        scrollArea->setWidget(scrollWidget);

        mainLayout->addWidget(scrollArea);


        QHBoxLayout *buttonLayout = new QHBoxLayout();

        QPushButton *cancelButton = new QPushButton("Cancel", &dialog);
        cancelButton->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:5px; border: 1px solid #000000; }");
        buttonLayout->addWidget(cancelButton);


        connect(cancelButton, &QPushButton::clicked, &dialog, &QDialog::reject);


        mainLayout->addLayout(buttonLayout);

        dialog.exec();
        }
    }else if(ui->pushButton_View->text()=="Fill"){
        QString surveyName = ui->lineEdit_Sondaj->text();


        client& Client = client::getInstance();
        QByteArray requestMessage;
        requestMessage.append("Vizualizareformular|");
        requestMessage.append(surveyName.toUtf8());
        const char* charArray = requestMessage.constData();
        Client.send_message(charArray);


        const char* response = Client.response();
        if(strcmp(response,"Formularul nu a fost gasit.")){
            QMessageBox::warning(this, "Warning", "Formularul nu a fost gasit!");
            //const char* response="i1*r1|i1*r2|i1*r3|i2*r4|i2*r5|i2*r6|";
        }
        else{
        QDialog dialog(this);
        dialog.setWindowTitle("Completează Formularul");
        dialog.resize(600, 400);
        QVBoxLayout *mainLayout = new QVBoxLayout(&dialog);
        dialog.setStyleSheet("background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(74, 144, 226, 255), stop:1 rgba(74, 144, 226, 0));");

        QScrollArea *scrollArea = new QScrollArea(&dialog);
        scrollArea->setWidgetResizable(true);


        QWidget *scrollWidget = new QWidget();
        QVBoxLayout *scrollLayout = new QVBoxLayout(scrollWidget);


        QString responseString(response);
        QStringList questionAnswerPairs = responseString.split("|");

        QMap<QString, QStringList> questionAnswerMap;


        for (const QString& pair : questionAnswerPairs) {
            QStringList questionAnswer = pair.split("*");
            if (questionAnswer.size() > 1) {
                QString question = questionAnswer[0];
                QString answer = questionAnswer[1];
                if (!questionAnswerMap.contains(question)) {
                    questionAnswerMap[question] = QStringList();
                }
                questionAnswerMap[question].append(answer);
            }
        }

        QVector<QComboBox*> answerComboBoxes;


        for (auto it = questionAnswerMap.constBegin(); it != questionAnswerMap.constEnd(); ++it) {
            QString question = it.key();
            QStringList answers = it.value();

            QLabel *questionLabel = new QLabel(question, &dialog);
            scrollLayout->addWidget(questionLabel);

            QComboBox *comboBox = new QComboBox(&dialog);
            for (const QString& answer : answers) {
                comboBox->addItem(answer);
            }
            scrollLayout->addWidget(comboBox);
            answerComboBoxes.push_back(comboBox);
        }


        scrollArea->setWidget(scrollWidget);


        mainLayout->addWidget(scrollArea);


        QHBoxLayout *buttonLayout = new QHBoxLayout();


        QPushButton *submitButton = new QPushButton("Submit", &dialog);
        submitButton->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:5px; border: 1px solid #000000; }");
        buttonLayout->addWidget(submitButton);


        QPushButton *cancelButton = new QPushButton("Cancel", &dialog);
        cancelButton->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:5px; border: 1px solid #000000; }");
        buttonLayout->addWidget(cancelButton);


        connect(cancelButton, &QPushButton::clicked, &dialog, &QDialog::reject);


        mainLayout->addLayout(buttonLayout);


        connect(submitButton, &QPushButton::clicked, [&]() {
            QByteArray responseMessage;
            responseMessage.append("Completeaza|");
            QByteArray utilizator = Client.getNume().toUtf8();
            responseMessage.append(utilizator);
            responseMessage.append("|");
            responseMessage.append(surveyName.toUtf8());
            responseMessage.append("|");


            for (auto it = questionAnswerMap.constBegin(); it != questionAnswerMap.constEnd(); ++it) {
                QString question = it.key();
                QStringList answers = it.value();


                responseMessage.append(question.toUtf8());
                responseMessage.append("*");


                if (!answers.isEmpty()) {

                    QString selectedAnswer = answerComboBoxes.takeFirst()->currentText();
                    responseMessage.append(selectedAnswer.toUtf8());
                }


                if (it != questionAnswerMap.constEnd() - 1) {
                    responseMessage.append("|");
                }
            }

            const char* responseCharArray = responseMessage.constData();
            Client.send_message(responseCharArray);
            dialog.accept();
        });
        dialog.exec();
        }
    }else if(ui->pushButton_View->text()=="Statistica"){
        QString nume = ui->lineEdit_Sondaj->text();

        client& Client = client::getInstance();
        QByteArray requestMessage;
        requestMessage.append("Statistica|");
        requestMessage.append(nume.toUtf8());
        const char* charArray = requestMessage.constData();
        Client.send_message(charArray);


        const char* response = Client.response();


        QDialog dialog(this);
        dialog.setWindowTitle("Vizualizare Formular");
        dialog.resize(600, 400);
        dialog.setStyleSheet("background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(74, 144, 226, 255), stop:1 rgba(74, 144, 226, 0));");
        QVBoxLayout *mainLayout = new QVBoxLayout(&dialog);


        QScrollArea *scrollArea = new QScrollArea(&dialog);
        scrollArea->setWidgetResizable(true);


        QWidget *scrollWidget = new QWidget();
        QVBoxLayout *scrollLayout = new QVBoxLayout(scrollWidget);


        QString responseString(response);
        QStringList questionAnswerPairs = responseString.split("|");

        for (const QString& pair : questionAnswerPairs) {
            QStringList questionAnswers = pair.split("*");
            QString question = questionAnswers[0];
            QLabel *questionLabel = new QLabel(question, &dialog);
            scrollLayout->addWidget(questionLabel);

            for (int i = 1; i < questionAnswers.size(); ++i) {
                QStringList answerPercentage = questionAnswers[i].split("+");
                QString answer = answerPercentage[0];
                QString percentage = answerPercentage[1];
                QLabel *answerLabel = new QLabel(QString("Raspuns%1: %2\nProcentaj: %3").arg(i).arg(answer).arg(percentage), &dialog);
                scrollLayout->addWidget(answerLabel);
            }
        }


        scrollArea->setWidget(scrollWidget);


        mainLayout->addWidget(scrollArea);


        QHBoxLayout *buttonLayout = new QHBoxLayout();

        QPushButton *cancelButton = new QPushButton("Cancel", &dialog);
        cancelButton->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:5px; border: 1px solid #000000; }");
        buttonLayout->addWidget(cancelButton);

        connect(cancelButton, &QPushButton::clicked, &dialog, &QDialog::reject);

        mainLayout->addLayout(buttonLayout);

        dialog.exec();
    }
    else if(ui->pushButton_View->text()=="Sterge"){
        client&Client=client::getInstance();
        QByteArray cerere;
        cerere.append("AprobaStergere|");
        QString nume = ui->lineEdit_Sondaj->text();
        cerere.append(nume.toUtf8());
        Client.send_message(cerere);
        const char*response=Client.response();
        QMessageBox::information(this,"Stergere",response);
        ui->lineEdit_Sondaj->clear();
    }else if(ui->pushButton_View->text()=="Arhiveaza"){
        client&Client=client::getInstance();
        QByteArray cerere;
        cerere.append("AprobaArhivare|");
        QString nume = ui->lineEdit_Sondaj->text();
        cerere.append(nume.toUtf8());
        Client.send_message(cerere);
        const char*response=Client.response();
        QMessageBox::information(this,"Arhivare",response);
        ui->lineEdit_Sondaj->clear();
    }
}


void Admin::on_pushButton_Cancel_clicked()
{
    ui->label_AlegereSondaj->setVisible(false);
    ui->lineEdit_Sondaj->setVisible(false);
    ui->pushButton_Cancel->setVisible(false);
    ui->pushButton_View->setVisible(false);
}


void Admin::on_pushButton_cont_clicked()
{
    QDialog dialog(this);
    dialog.setWindowTitle("Cont");
    dialog.resize(300, 150);
    QVBoxLayout *mainLayout = new QVBoxLayout(&dialog);
    dialog.setStyleSheet("background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(74, 144, 226, 255), stop:1 rgba(74, 144, 226, 0));");

    QHBoxLayout *buttonLayout = new QHBoxLayout();

    QPushButton *cancelButton = new QPushButton("Cancel", &dialog);
    cancelButton->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:5px; border: 1px solid #000000; }");
    buttonLayout->addWidget(cancelButton);

    QPushButton *deconectareButton = new QPushButton("Deconectare", &dialog);
    deconectareButton->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:5px; border: 1px solid #000000; }");
    buttonLayout->addWidget(deconectareButton);

    mainLayout->addLayout(buttonLayout);

    connect(cancelButton, &QPushButton::clicked, &dialog, &QDialog::reject);

    connect(deconectareButton, &QPushButton::clicked, [&]() {
        static MainWindow w;
        hide();
        w.show();
        dialog.accept();
    });

    dialog.exec();
}


void Admin::on_pushButton_VizualizareStergeri_clicked()
{

    ui->listWidget->clear();
    ui->label_vizualizare->setVisible(true);
    ui->listWidget->setVisible(true);
    ui->pushButton_Clear->setVisible(true);
    ui->label_vizualizare->setText("Cereri stergere");
    client& Client=client::getInstance();
    QByteArray authMessage;
    authMessage.append("VizualizareStergere|");
    const char* charArray = authMessage.constData();
    Client.send_message(charArray);
    const char*response=Client.response();
    QString responseStr(response);
    QStringList namesList = responseStr.split('|');
    foreach (const QString &name, namesList) {
        ui->listWidget->addItem(name);
    }
}

