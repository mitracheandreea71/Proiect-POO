#include "user.h"
#include "ui_user.h"
#include<QPainter>
#include"conexiuneserver.h"
#include<QVBoxLayout>
#include<QMessageBox>
#include<QScrollArea>
#include<QString>
#include<QRadioButton>
#include<QComboBox>
#include"mainwindow.h".;

User::User(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::User)
{
    ui->setupUi(this);
    QPixmap img("C:/Users/mitra/Desktop/client/slt.png");
    QBitmap mask(img.size());
    mask.fill(Qt::color0);
    QPainter painter(&mask);
    painter.setBrush(Qt::color1);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.drawEllipse(mask.rect());
    img.setMask(mask);

    ui->label_imgUser->setPixmap(img);
    ui->label_imgUser->setScaledContents(true);
    client& Client=client::getInstance();

    ui->pushButton_cont->setText(Client.getNume());
/*
    connect(ui->pushButton_VizSC, &QPushButton::clicked, this, &User::on_pushButton_VizSC_clicked);
    connect(ui->pushButton_VizSN, &QPushButton::clicked, this, &User::on_pushButton_VizSN_clicked);
    connect(ui->pushButton_VizSC_2, &QPushButton::clicked, this, &User::on_pushButton_VizSC_2_clicked);
    connect(ui->pushButton_CompletareS, &QPushButton::clicked, this, &User::on_pushButton_CompletareS_clicked);
    connect(ui->pushButton_Clear, &QPushButton::clicked, this, &User::on_pushButton_Clear_clicked);
    connect(ui->pushButton_View, &QPushButton::clicked, this, &User::on_pushButton_View_clicked);
    connect(ui->pushButton_Cancel, &QPushButton::clicked, this, &User::on_pushButton_Cancel_clicked);
    connect(ui->pushButton_VizSC, SIGNAL(clicked()), this, SLOT(displayNames()));*/
    ui->label_AlegereSondaj->setVisible(false);
    ui->label_vizualizare->setVisible(false);
    ui->listWidget->setVisible(false);
    ui->pushButton_Clear->setVisible(false);
    ui->lineEdit_Sondaj->setVisible(false);
    ui->pushButton_Cancel->setVisible(false);
    ui->pushButton_View->setVisible(false);

}

User::~User()
{
    delete ui;
}

void User::on_pushButton_cont_clicked()
{
    QDialog dialog(this);
    dialog.setWindowTitle("Cont");
    dialog.resize(300, 150);
    QVBoxLayout *mainLayout = new QVBoxLayout(&dialog);
    dialog.setStyleSheet("background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(74, 144, 226, 255), stop:1 rgba(74, 144, 226, 0));");

    QHBoxLayout *buttonLayout = new QHBoxLayout();

    QPushButton *cancelButton = new QPushButton("Cancel", &dialog);
    cancelButton->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:5px; border: 1px solid #000000; }");
    buttonLayout->addWidget(cancelButton);

    QPushButton *deconectareButton = new QPushButton("Deconectare", &dialog);
    deconectareButton->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:5px; border: 1px solid #000000; }");
    buttonLayout->addWidget(deconectareButton);

    mainLayout->addLayout(buttonLayout);

    connect(cancelButton, &QPushButton::clicked, &dialog, &QDialog::reject);

    connect(deconectareButton, &QPushButton::clicked, [&]() {
        static MainWindow w;
        hide();
        w.show();
        dialog.accept();
    });

    dialog.exec();
}

void User::on_pushButton_VizSC_clicked()
{
    ui->listWidget->clear();
    ui->label_vizualizare->setVisible(true);
    ui->listWidget->setVisible(true);
    ui->pushButton_Clear->setVisible(true);
    ui->label_vizualizare->setText("Formulare completate");
    client& Client=client::getInstance();
    QByteArray authMessage;
    authMessage.append("FormulareCompletate|");
    QByteArray usernameBytes = Client.getNume().toUtf8();
    authMessage.append(usernameBytes);
    const char* charArray = authMessage.constData();
    Client.send_message(charArray);
    const char*response=Client.response();
    QString responseStr(response);
    QStringList namesList = responseStr.split('|');
    foreach (const QString &name, namesList) {
        ui->listWidget->addItem(name);
    }
     //const char*response1=Client.response();
}

void User::on_pushButton_VizSN_clicked()
{
    ui->listWidget->clear();
    ui->label_vizualizare->setVisible(true);
    ui->listWidget->setVisible(true);
    ui->pushButton_Clear->setVisible(true);
    ui->label_vizualizare->setText("Formulare necompletate");
    client& Client=client::getInstance();
    QByteArray authMessage;
    authMessage.append("FormulareNecompletate|");
    QByteArray usernameBytes = Client.getNume().toUtf8();
    authMessage.append(usernameBytes);
    const char* charArray = authMessage.constData();
    Client.send_message(charArray);
    const char*response=Client.response();

    QString responseStr(response);
    QStringList namesList = responseStr.split('|');
    foreach (const QString &name, namesList) {
        ui->listWidget->addItem(name);
    }
   //  const char*response1=Client.response();
}

void User::on_pushButton_CompletareS_clicked()
{
    ui->lineEdit_Sondaj->clear();
    ui->label_AlegereSondaj->setVisible(true);
    ui->lineEdit_Sondaj->setVisible(true);
    ui->pushButton_Cancel->setVisible(true);
    ui->pushButton_View->setVisible(true);
    ui->pushButton_View->setText("Fill");
    ui->label_AlegereSondaj->setText("Completeaza numele formularului pe care doresti sa-l completezi:");

}

void User::on_pushButton_VizSC_2_clicked()
{
    ui->lineEdit_Sondaj->clear();
    ui->label_AlegereSondaj->setVisible(true);
    ui->lineEdit_Sondaj->setVisible(true);
    ui->pushButton_Cancel->setVisible(true);
    ui->pushButton_View->setVisible(true);
     ui->pushButton_View->setText("View");
    ui->label_AlegereSondaj->setText("Completeaza numele formularului pe care doresti sa-l vizualizezi:");
}

void User::on_pushButton_Clear_clicked()
{
    ui->label_vizualizare->setVisible(false);
    ui->listWidget->setVisible(false);
    ui->pushButton_Clear->setVisible(false);
    ui->listWidget->clear();
}

void User::on_pushButton_Cancel_clicked()
{
    ui->label_AlegereSondaj->setVisible(false);
    ui->lineEdit_Sondaj->setVisible(false);
    ui->pushButton_Cancel->setVisible(false);
    ui->pushButton_View->setVisible(false);
}

void User::on_groupBox_clicked()
{

}

void User::on_pushButton_View_clicked()
{
    if(ui->pushButton_View->text()=="View"){

        QString nume=ui->lineEdit_Sondaj->text();

        client& Client = client::getInstance();
        QByteArray requestMessage;
        requestMessage.append("FormularCompletatDeMine|");
        requestMessage.append(Client.getNume().toUtf8());
        requestMessage.append("|");
        requestMessage.append(nume.toUtf8());
        const char* charArray = requestMessage.constData();
        Client.send_message(charArray);

        const char* response = Client.response();
      //  const char*response="i1*r1|i2*r2|i3*r2|i4*r4|";
        if(strcmp(response,"Formular gresit")==0){
            QMessageBox::warning(this, "Warning", "Formularul nu e completat");
        }
        else{
        QDialog dialog(this);
        dialog.setWindowTitle("Vizualizare Formular");
        dialog.resize(600, 400);
        dialog.setStyleSheet("background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(74, 144, 226, 255), stop:1 rgba(74, 144, 226, 0));");
        QVBoxLayout *mainLayout = new QVBoxLayout(&dialog);


        QScrollArea *scrollArea = new QScrollArea(&dialog);
        scrollArea->setWidgetResizable(true);


        QWidget *scrollWidget = new QWidget();
        QVBoxLayout *scrollLayout = new QVBoxLayout(scrollWidget);


        QString responseString(response);
        QStringList questionAnswerPairs = responseString.split("|");

        for (const QString& pair : questionAnswerPairs) {
            QStringList questionAnswer = pair.split("*");

            if (questionAnswer.size() == 2) {
                QString question = questionAnswer[0];
                QString answer = questionAnswer[1];

                QLabel *questionLabel = new QLabel(question, &dialog);
                QLabel *answerLabel = new QLabel(answer, &dialog);

                scrollLayout->addWidget(questionLabel);
                scrollLayout->addWidget(answerLabel);
            }
        }


        scrollArea->setWidget(scrollWidget);


        mainLayout->addWidget(scrollArea);
        QHBoxLayout *buttonLayout = new QHBoxLayout();


        QPushButton *cancelButton = new QPushButton("Cancel", &dialog);
        cancelButton->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:5px; border: 1px solid #000000; }");
        buttonLayout->addWidget(cancelButton);

        connect(cancelButton, &QPushButton::clicked, &dialog, &QDialog::reject);


        mainLayout->addLayout(buttonLayout);

        dialog.exec();
        }
    }else if(ui->pushButton_View->text()=="Fill"){
        QString surveyName = ui->lineEdit_Sondaj->text();
        client& Client = client::getInstance();
        QByteArray requestMessage;
        requestMessage.append("Vizualizareformular|");
        requestMessage.append(surveyName.toUtf8());
        const char* charArray = requestMessage.constData();
        Client.send_message(charArray);

        const char* response = Client.response();
        //const char* response="i1*r1|i1*r2|i1*r3|i2*r4|i2*r5|i2*r6|";
        if(strcmp(response,"Formularul nu a fost gasit.")==0){
            QMessageBox::warning(this, "Warning", "Formularul nu a fost gasit!");
            //const char* response="i1*r1|i1*r2|i1*r3|i2*r4|i2*r5|i2*r6|";
        }
        else{
        QDialog dialog(this);
        dialog.setWindowTitle("Completează Formularul");
        dialog.resize(600, 400);
        QVBoxLayout *mainLayout = new QVBoxLayout(&dialog);
        dialog.setStyleSheet("background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(74, 144, 226, 255), stop:1 rgba(74, 144, 226, 0));");

        QScrollArea *scrollArea = new QScrollArea(&dialog);
        scrollArea->setWidgetResizable(true);


        QWidget *scrollWidget = new QWidget();
        QVBoxLayout *scrollLayout = new QVBoxLayout(scrollWidget);

        QString responseString(response);
        QStringList questionAnswerPairs = responseString.split("|");

        QMap<QString, QStringList> questionAnswerMap;

        for (const QString& pair : questionAnswerPairs) {
            QStringList questionAnswer = pair.split("*");
            if (questionAnswer.size() > 1) {
                QString question = questionAnswer[0];
                QString answer = questionAnswer[1];
                if (!questionAnswerMap.contains(question)) {
                    questionAnswerMap[question] = QStringList();
                }
                questionAnswerMap[question].append(answer);
            }
        }

        QVector<QComboBox*> answerComboBoxes;

        for (auto it = questionAnswerMap.constBegin(); it != questionAnswerMap.constEnd(); ++it) {
            QString question = it.key();
            QStringList answers = it.value();

            QLabel *questionLabel = new QLabel(question, &dialog);
            scrollLayout->addWidget(questionLabel);

            QComboBox *comboBox = new QComboBox(&dialog);
            for (const QString& answer : answers) {
                comboBox->addItem(answer);
            }
            scrollLayout->addWidget(comboBox);
            answerComboBoxes.push_back(comboBox);
        }

        scrollArea->setWidget(scrollWidget);

        mainLayout->addWidget(scrollArea);

        QHBoxLayout *buttonLayout = new QHBoxLayout();

        QPushButton *submitButton = new QPushButton("Submit", &dialog);
        submitButton->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:5px; border: 1px solid #000000; }");
        buttonLayout->addWidget(submitButton);

        QPushButton *cancelButton = new QPushButton("Cancel", &dialog);
        cancelButton->setStyleSheet("QPushButton { border:none; color:black; background-color:white; border-radius:5px; border: 1px solid #000000; }");
        buttonLayout->addWidget(cancelButton);

        connect(cancelButton, &QPushButton::clicked, &dialog, &QDialog::reject);

        mainLayout->addLayout(buttonLayout);

        connect(submitButton, &QPushButton::clicked, [&]() {
            QByteArray responseMessage;
            responseMessage.append("Completeaza|");
            QByteArray utilizator = Client.getNume().toUtf8();
            responseMessage.append(utilizator);
            responseMessage.append("|");
            responseMessage.append(surveyName.toUtf8());
            responseMessage.append("|");

            for (auto it = questionAnswerMap.constBegin(); it != questionAnswerMap.constEnd(); ++it) {
                QString question = it.key();
                QStringList answers = it.value();

                responseMessage.append(question.toUtf8());
                responseMessage.append("*");

                if (!answers.isEmpty()) {
                    QString selectedAnswer = answerComboBoxes.takeFirst()->currentText();
                    responseMessage.append(selectedAnswer.toUtf8());
                }
                if (it != questionAnswerMap.constEnd() - 1) {
                    responseMessage.append("|");
                }
            }

            const char* responseCharArray = responseMessage.constData();
            Client.send_message(responseCharArray);
            dialog.accept();
        });
        dialog.exec();
        }
    }
}

