#ifndef MANAGER_H
#define MANAGER_H

#include <QMainWindow>

namespace Ui {
class Manager;
}

class Manager : public QMainWindow
{
    Q_OBJECT

public:
    explicit Manager(QWidget *parent = nullptr);
    ~Manager();

private slots:
    void on_pushButton_cont_clicked();

    void on_pushButton_VizSC_clicked();

    void on_pushButton_VizSN_clicked();

    void on_pushButton_VizFCreate_clicked();

    void on_pushButton_VizStatistica_clicked();

    void on_pushButton_VizFromuar_clicked();

    void on_pushButton_CompletareS_clicked();

    void on_pushButton_CreareF_clicked();

    void on_pushButton_Clear_clicked();

    void on_pushButton_View_clicked();

    void on_pushButton_Cancel_clicked();

    void showNameAndQuestionCountDialogS(const QString &windowTitle);

    void showQuestionsDialogS(const QString &surveyName, int questionCount);

    void showNameAndQuestionCountDialogC(const QString &windowTitle);

    void showQuestionsDialogC(const QString &surveyName, int questionCount);


    void on_pushButton_CerereArhivare_clicked();



    void on_pushButton_Stergere_clicked();

    void on_pushButton_RecuperareFormular_clicked();

private:
    Ui::Manager *ui;
};

#endif // MANAGER_H
