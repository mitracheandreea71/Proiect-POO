#ifndef USER_H
#define USER_H

#include <QMainWindow>

namespace Ui {
class User;
}

class User : public QMainWindow
{
    Q_OBJECT

public:
    explicit User(QWidget *parent = nullptr);
    ~User();

private slots:
    void on_pushButton_cont_clicked();

    void on_pushButton_VizSC_clicked();

    void on_pushButton_VizSN_clicked();

    void on_pushButton_CompletareS_clicked();

    void on_pushButton_VizSC_2_clicked();

    void on_pushButton_Clear_clicked();

    void on_pushButton_Cancel_clicked();

    void on_groupBox_clicked();

    void on_pushButton_View_clicked();



private:
    Ui::User *ui;

};

#endif // USER_H
