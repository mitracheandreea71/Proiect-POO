#include "sign.h"
#include "ui_sign.h"
#include"mainwindow.h"
#include<QMessageBox>
#include"conexiuneserver.h"
#include"user.h"
#include"manager.h"
#include"admin.h"
Sign::Sign(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Sign)
{
    ui->setupUi(this);
}

Sign::~Sign()
{
    delete ui;
}

void Sign::on_pushButton_Sign_clicked()
{
    QString username = ui->lineEdit_UserName->text();
    QString password = ui->lineEdit_Password->text();
    QString organization = ui->lineEdit_Organization->text();
    QByteArray authMessage;
    authMessage.append("R|");
    QByteArray usernameBytes = username.toUtf8();
    QByteArray passwordBytes = password.toUtf8();
    QByteArray organizationBytes = organization.toUtf8();
    authMessage.append(usernameBytes);
    authMessage.append("|");
    authMessage.append(passwordBytes);
    authMessage.append("|");
    client& Client=client::getInstance();
    QString tipUtilizator;
    if(ui->radioButton_Admin->isChecked()){
         authMessage.append("admin");
        tipUtilizator="admin";
    }else if(ui->radioButton_Manager->isChecked()){
        authMessage.append("manager");
        tipUtilizator="manager";
    } else{
        authMessage.append("user");
        tipUtilizator="user";
    }
    authMessage.append("|");
    authMessage.append(organizationBytes);
    const char* charArray = authMessage.constData();
    Client.send_message(charArray);
    const char*response=Client.response();
    if(strcmp(response,"Inregistrare esuata. Nume de utilizator indisponibil.")==0){
        QMessageBox::information(this,"Sign","Inregistrare esuata. Numele de utilizator indisponibil.");
    }
    else if(strcmp(response,"Numele organizatiei nu exista.")==0){
         QMessageBox::information(this,"Sign","Inregistrare esuata. Organizatia nu exista.");
    }else if(strcmp(response,"Inregistrare esuata")==0){
        QMessageBox::information(this,"Sign","Inregistrare esuata");
    }
    else{
        Client.saveNumeUtilizator(username);;
        if(tipUtilizator=="user"){
            static User u;
            hide();
            u.show();
        }else if(tipUtilizator=="manager"){
            static Manager u;
            hide();
            u.show();
        }else{
            static Admin u;
            hide();
            u.show();
        }

    }
    ui->lineEdit_Organization->clear();
    ui->lineEdit_Password->clear();
    ui->lineEdit_UserName->clear();
}


void Sign::on_pushButton_Cancel_clicked()
{
    static MainWindow w;
    hide();
    w.show();
}

