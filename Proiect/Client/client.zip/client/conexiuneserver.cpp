#include "conexiuneserver.h"

#include<cstdio>

#include <iostream>
#include <cstring>
#include <unistd.h>
const int BUFFER_SIZE = 1024;

client::client()
{
    WSADATA wsaData;

    WSAStartup(MAKEWORD(2,2), &wsaData);

    client_socket=socket(AF_INET,SOCK_STREAM, IPPROTO_TCP);

    sockaddr_in clientService;
    clientService.sin_family=AF_INET;
    inet_pton(AF_INET,"172.20.10.9",&clientService.sin_addr.s_addr);
    // inet_pton(AF_INET,"127.0.0.1",&clientService.sin_addr.s_addr);
    clientService.sin_port=htons(8080);
    int ret=connect(client_socket,(sockaddr*)&clientService,sizeof(clientService));
    if(ret==SOCKET_ERROR){
        printf("Conectare la server esuata cu eroarea:%d\n",WSAGetLastError());
    }else{
        printf("Conectare la server reusita!\n");
    }

}

client::~client(){
    closesocket(client_socket);
    WSACleanup();
}

void client::send_message(const char *buffer){
    send(client_socket,buffer,strlen(buffer)+1,0);
}

const char* client::response(){
    static char response[BUFFER_SIZE];
    memset(response, 0, BUFFER_SIZE);
    int bytes_received = recv(client_socket, response, BUFFER_SIZE - 1, 0);
    if (bytes_received < 0) {
        close(client_socket);
        return nullptr;
    } else if (bytes_received == 0) {      
        close(client_socket);
        return nullptr;
    }
    return response;
}

void client::saveNumeUtilizator(QString nume){
    numeUtilizator=nume;
}
