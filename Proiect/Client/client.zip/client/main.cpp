#include "mainwindow.h"
#include"conexiuneserver.h"
#include <QApplication>
#include<QLabel>
#include"manager.h"
#include"admin.h"
int main(int argc, char *argv[])
{

    QApplication a(argc, argv);
   // Admin u;
   // u.show();
   MainWindow w;
     w.show();
    client& Client = client::getInstance();
    return a.exec();
}
