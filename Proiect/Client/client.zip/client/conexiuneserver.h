#ifndef CONEXIUNESERVER_H
#define CONEXIUNESERVER_H
//singleton
#include <QMainWindow>
#undef UNICODE
#define _CRT_SECURE_NO_WARNINGS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdio.h>
class client
{
private:
    SOCKET client_socket;
    client();
    ~client();
    client(const client&) = delete;
    client& operator=(const client&)=delete;
     QString numeUtilizator="user";
public:
    static client& getInstance(){
        static client instance;
        return instance;
    }
    void send_message(const char*buffer);
    const char*response();
    void saveNumeUtilizator(QString nume);
    QString getNume(){
        return numeUtilizator;
    }

};

#endif // CONEXIUNESERVER_H
