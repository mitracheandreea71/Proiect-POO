#include "login.h"
#include "ui_login.h"
#include"mainwindow.h"
#include"conexiuneserver.h"
#include"user.h"
#include"manager.h"
#include"admin.h"
Login::Login(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Login)
{
    ui->setupUi(this);
   // ui->lineEdit_Password->clear();
   // ui->lineEdit_UserName->clear();
}

Login::~Login()
{
    delete ui;
}

void Login::on_pushButton_Login_clicked()
{
    QString username = ui->lineEdit_UserName->text();
    QString password = ui->lineEdit_Password->text();
    QByteArray authMessage;
    authMessage.append("A|");
    QByteArray usernameBytes = username.toUtf8();
    QByteArray passwordBytes = password.toUtf8();
    authMessage.append(usernameBytes);
    authMessage.append("|");
    authMessage.append(passwordBytes);
    const char* charArray = authMessage.constData();
   // charArray="R|utilizator3|parola3|user";
    client& Client1=client::getInstance();

     Client1.send_message(charArray);
     const char*response=Client1.response();
     if(strcmp(response,"Autentificare reusita.")==0){
         Client1.saveNumeUtilizator(username);
         QByteArray authMessage2;
         authMessage2.append("T|");
          authMessage2.append(usernameBytes);
         charArray = authMessage2.constData();
         Client1.send_message(charArray);
         const char* response1 = Client1.response();
         if(strcmp(response1,"user")==0){
            static User u;
             hide();
             u.show();
         }else if(strcmp(response1,"manager")==0){
             static Manager u;
             hide();
             u.show();
         }else{
             static Admin u;
             hide();
             u.show();
         }

     }
     else{
         QMessageBox::information(this,"Login","Autentificare esuata! Numele de utilizator sau parola invalida!");
     }

     ui->lineEdit_Password->clear();
     ui->lineEdit_UserName->clear();
}


void Login::on_pushButton_Cancel_clicked()
{
    static MainWindow w;
    hide();
    w.show();
}

