#ifndef ADMIN_H
#define ADMIN_H

#include <QMainWindow>

namespace Ui {
class Admin;
}

class Admin : public QMainWindow
{
    Q_OBJECT

public:
    explicit Admin(QWidget *parent = nullptr);
    ~Admin();

private slots:
    void on_pushButton_VizSC_clicked();

    void on_pushButton_VizSN_clicked();

    void on_pushButton_VizFCreate_clicked();

    void on_pushButton_VizStatistica_clicked();

    void on_pushButton_VizFormular_clicked();



    void on_pushButton_CompletareS_clicked();


    void showNameAndQuestionCountDialogS(const QString &windowTitle);

    void showQuestionsDialogS(const QString &surveyName, int questionCount);

    void showNameAndQuestionCountDialogC(const QString &windowTitle);

    void showQuestionsDialogC(const QString &surveyName, int questionCount);


    void on_pushButton_CreareF_clicked();

    void on_pushButton_CerereArhivare_clicked();

    void on_pushButton_StergereF_clicked();

    void on_pushButton_ArhivareF_clicked();

    void on_pushButton_Clear_clicked();

    void on_pushButton_View_clicked();

    void on_pushButton_Cancel_clicked();

    void on_pushButton_cont_clicked();

    void on_pushButton_VizualizareStergeri_clicked();

private:
    Ui::Admin *ui;
};

#endif // ADMIN_H
